# My First Project > 2026-11-24 11:14pm
https://universe.roboflow.com/ricardos-workspace-etwvc/my-first-project-5nwhr

Provided by a Roboflow user
License: CC BY 4.0

